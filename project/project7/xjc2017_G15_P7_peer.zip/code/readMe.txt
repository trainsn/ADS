sourse code  --  xjc2017_G15_P7.cpp 
code for test cases -- p7_test.cpp		 
sample data -- p7-1000.out		
			   p7-3000.out
			   p7-10000.out
			   p7-30000.out
			   p7-100000.out
